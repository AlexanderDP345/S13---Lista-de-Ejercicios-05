
public class Main {

	public static void main(String[] args) {
		Thread t = new Thread(new Mensaje("Hola", 5), "Hilo t");
		
		t.start();
		
		
        while (t.isAlive()) {
            System.out.println("El Hilo t aún está ejecutándose...");
            try {
                Thread.sleep(500); 
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        System.out.println("El Hilo t ha terminado de ejecutar");
	}

}
