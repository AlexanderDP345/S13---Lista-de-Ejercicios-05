
public class Mensaje implements Runnable {
	
	private String mensaje;
    private int repeticiones;
	
    public Mensaje(String mensaje, int repeticiones) {
    	this.mensaje = mensaje;
        this.repeticiones = repeticiones;
	}
	@Override
	public void run() {
		for (int i = 0; i < repeticiones; i++) {
            System.out.println(Thread.currentThread().getName() + " - " + mensaje + " (Repetición " + (i + 1) + ")");
            try {
                Thread.sleep(1000); 
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        } 
	 }
		
}


