package Pregunta12;

public class Main {
    public static void main(String[] args) {
        Sleeper sleeper = new Sleeper();
        sleeper.sleep(4000); // Poner a dormir el hilo por 4 segundos
    }
}

