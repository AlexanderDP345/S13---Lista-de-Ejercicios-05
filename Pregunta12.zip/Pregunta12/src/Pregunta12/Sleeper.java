package Pregunta12;

public class Sleeper {
    public void sleep(int milliseconds) {
        try {
            System.out.println("El hilo se va a dormir por " + milliseconds + " milisegundos...");
            Thread.sleep(milliseconds);
            System.out.println("El hilo se despertó.");
        } catch (InterruptedException e) {
            System.out.println("El hilo fue interrumpido mientras dormía.");
        }
    }
}
