package Pregunta08;

public class Counter {
    private static int staticCount = 0;
    private int instanceCount = 0;

    public synchronized void incrementInstance() {
        instanceCount++;
    }

    public static synchronized void incrementStatic() {
        staticCount++;
    }

    public int getInstanceCount() {
        return instanceCount;
    }

    public static int getStaticCount() {
        return staticCount;
    }
}
