package Ejercicio1;

public class Transaccion implements Runnable{
	
	private CuentaBancaria cuenta;
    private boolean esDeposito;
    private double cantidad;

    public Transaccion(CuentaBancaria cuenta, boolean esDeposito, double cantidad) {
        this.cuenta = cuenta;
        this.esDeposito = esDeposito;
        this.cantidad = cantidad;
    }

	@Override
	public void run() {
		if (esDeposito) {
            cuenta.depositar(cantidad);
        } else {
            cuenta.retirar(cantidad);
        }
		
	}

}
