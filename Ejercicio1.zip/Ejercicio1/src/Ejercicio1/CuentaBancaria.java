package Ejercicio1;

public class CuentaBancaria {
    private double saldo;

    public CuentaBancaria(double saldoInicial) {
        this.saldo = saldoInicial;
    }

    public synchronized void depositar(double cantidad) {
        saldo += cantidad;
        System.out.println(Thread.currentThread().getName() + " depositó: " + cantidad + ", Saldo actual: " + saldo);
    }

    public synchronized void retirar(double cantidad) {
        if (cantidad <= saldo) {
            saldo -= cantidad;
            System.out.println(Thread.currentThread().getName() + " retiró: " + cantidad + ", Saldo actual: " + saldo);
        } else {
            System.out.println(Thread.currentThread().getName() + " intentó retirar: " + cantidad + ", pero el saldo es insuficiente. Saldo actual: " + saldo);
        }
    }

    public double getSaldo() {
        return saldo;
    }
}
