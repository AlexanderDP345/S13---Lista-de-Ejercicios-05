package Ejercicio1;

public class Main {

	public static void main(String[] args) {
		CuentaBancaria cuenta = new CuentaBancaria(500.0);

        Thread deposito1 = new Thread(new Transaccion(cuenta, true, 150.0), "Deposito 1");
        Thread retiro1 = new Thread(new Transaccion(cuenta, false, 100.0), "Retiro 1");
        Thread deposito2 = new Thread(new Transaccion(cuenta, true, 200.0), "Deposito 2");
        Thread retiro2 = new Thread(new Transaccion(cuenta, false, 50.0), "Retiro 2");

        deposito1.start();
        retiro1.start();
        deposito2.start();
        retiro2.start();

        try {
            deposito1.join();
            retiro1.join();
            deposito2.join();
            retiro2.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("Saldo final: " + cuenta.getSaldo());
    

	}

}
