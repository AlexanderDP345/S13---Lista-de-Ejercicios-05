package Pregunta13;

public class ControlledTask implements Runnable {
    private volatile boolean running = true;

    @Override
    public void run() {
        while (running) {
            try {
                System.out.println("El hilo está corriendo...");
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                System.out.println("Hilo interrumpido durante el sueño.");
            }
        }
        System.out.println("Hilo detenido.");
    }

    public void stop() {
        running = false;
    }
}
