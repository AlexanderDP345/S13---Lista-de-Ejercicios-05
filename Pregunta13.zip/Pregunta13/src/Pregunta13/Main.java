package Pregunta13;

public class Main {
    public static void main(String[] args) throws InterruptedException {
        ControlledTask task = new ControlledTask();
        Thread thread = new Thread(task);
        thread.start();

        // Dormir por un poco de tiempo y luego detener el hilo
        Thread.sleep(5000);
        task.stop();
    }
}

