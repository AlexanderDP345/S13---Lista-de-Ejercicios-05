package Pregunta05;
public class MyRunnable implements Runnable {
    @Override
    public void run() {
        System.out.println("El Runnable se esta ejecutando en un hilo separado.");
    }
}
