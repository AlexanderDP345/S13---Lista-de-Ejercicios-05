package Pregunta05;
public class Main {
    public static void main(String[] args) {
        // Crear un objeto MyRunnable
        Runnable runnable = new MyRunnable();

        // Crear un Thread con ese Runnable
        Thread thread = new Thread(runnable);
        thread.start();

        try {
            // Esperar a que el hilo termine
            thread.join();
        } catch (InterruptedException e) {
            System.out.println("Hilo principal interrumpido.");
        }

        System.out.println("Hilo principal finalizado.");
    }
}
