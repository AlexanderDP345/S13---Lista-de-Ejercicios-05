package Pregunta09;

public class Main {
    public static void main(String[] args) {
        SharedObject obj = new SharedObject();

        Thread thread1 = new Thread(() -> {
            synchronized (obj) {
                obj.doSomething();
            }
        });

        Thread thread2 = new Thread(() -> {
            synchronized (obj) {
                obj.doSomething();
            }
        });

        thread1.start();
        thread2.start();
    }
}

class SharedObject {
    public void doSomething() {
        System.out.println(Thread.currentThread().getName() + " está haciendo algo en el objeto compartido.");
    }
}
