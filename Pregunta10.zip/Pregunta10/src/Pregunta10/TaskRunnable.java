package Pregunta10;

public class TaskRunnable implements Runnable {
    @Override
    public void run() {
        try {
            for (int i = 0; i < 10; i++) {
                Thread.sleep(1000);  // Simula trabajo durmiendo el hilo por 1 segundo.
                System.out.println("Ejecutando... " + (i + 1));
            }
        } catch (InterruptedException e) {
            System.out.println("Hilo interrumpido durante la ejecución.");
        }
    }
}
