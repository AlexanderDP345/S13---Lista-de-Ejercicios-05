package Pregunta10;

public class Main {
    public static void main(String[] args) {
        // Crear un objeto TaskRunnable
        Runnable runnable = new TaskRunnable();

        // Crear un Thread con ese Runnable
        Thread thread = new Thread(runnable);
        thread.start();

        try {
            // Esperar 7 segundos antes de interrumpir el hilo
            Thread.sleep(7000);
            thread.interrupt();
        } catch (InterruptedException e) {
            System.out.println("Hilo principal interrumpido.");
        }

        try {
            // Esperar a que el hilo termine
            thread.join();
        } catch (InterruptedException e) {
            System.out.println("Hilo principal interrumpido al esperar a que el hilo termine.");
        }

        System.out.println("Hilo principal terminado.");
    }
}

